export { default } from "./ConfigPanel";
