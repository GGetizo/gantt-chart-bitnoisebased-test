import { TooltipData } from "@/types/global";

export type TooltipProps = {
  tooltipData: TooltipData;
  zoom: number;
};
